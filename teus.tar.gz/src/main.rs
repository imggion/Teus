mod config;
mod monitor;
mod utils;
mod webserver;

use monitor::sys::SysInfo;
use std::{
    env,
    path::Path,
    process,
    sync::{
        Arc,
        atomic::{AtomicBool, Ordering},
    },
    thread,
};

fn main() {
    println!("Starting Teus service...");
    let args: Vec<String> = env::args().collect();
    let config_path = if args.len() > 1 {
        let path = &args[1];
        // Check if the provided file exists.
        if !Path::new(path).exists() {
            eprintln!("Configuration file '{}' does not exist.", path);
            process::exit(1);
        }
        path.clone()
    } else {
        // Use default config path if none is provided.
        "/etc/systemd/teus.toml".to_string()
    };

    let config = match config::parser::load_config(config_path) {
        Ok(cfg) => cfg,
        Err(e) => {
            eprintln!("Error loading configuration: {}", e);
            return;
        }
    };

    let running = Arc::new(AtomicBool::new(true));
    let r = running.clone();

    // Handle Ctrl+C (SIGINT)
    ctrlc::set_handler(move || {
        println!("Signal received, stopping...");
        r.store(false, Ordering::SeqCst);
    })
    .expect("Failed to set Ctrl+C handler");

    // Start the webserver in a separate thread
    let config_clone = config.clone();
    let web_handle_thread = thread::spawn(move || {
        // This will run the webserver in a separate thread
        let _ = webserver::api::start_webserver(&config_clone);
    });

    // Give the webserver a moment to start
    std::thread::sleep(std::time::Duration::from_millis(500));
    println!("Teus service started");

    // Run the system monitor in the main thread
    while running.load(Ordering::SeqCst) {
        let sysinfo = SysInfo::default();
        sysinfo.run_monitor(&config);

        thread::sleep(std::time::Duration::from_secs(config.monitor.interval_secs));
    }

    // Wait for the webserver to finish and ensure a clean shutdown
    println!("Closing, waiting for other threads to finish...");
    if let Err(e) = web_handle_thread.join() {
        eprintln!("Error waiting for webserver thread: {:?}", e);
    }
}
